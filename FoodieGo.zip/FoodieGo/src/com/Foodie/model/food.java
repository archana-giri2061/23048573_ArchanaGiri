/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Foodie.model;
/**
 * Represents a food item with various attributes such as name, price, quantity, 
 * ingredients, calorie count, vegetarian status, custom additions, and portion size.
 * 
 * @author 23028573_ArchanaGiri
 */
public class food {
    // Food item attributes
    private String name;
    private double price;
    private int Quantity;
    private String Ingredients;
    private int Calorie;
    private Boolean IsVegetrain;
    private String CustomAdd;
    private String portionSize;

    /**
     * Constructs a new food object with the specified attributes.
     *
     * @param name         Name of the food item
     * @param price        Price of the food item
     * @param Quantity     Quantity available
     * @param Ingredients  Ingredients used
     * @param Calorie      Calorie count
     * @param IsVegetrain  True if vegetarian, false otherwise
     * @param CustomAdd    Custom additions or preferences
     * @param portionSize  Portion size description
     */
    public food(String name, double price, int Quantity, String Ingredients, int Calorie, Boolean IsVegetrain, String CustomAdd, String portionSize) {
        this.name = name;
        this.price = price;
        this.Quantity = Quantity;
        this.Ingredients = Ingredients;
        this.Calorie = Calorie;
        this.IsVegetrain = IsVegetrain;
        this.CustomAdd = CustomAdd;
        this.portionSize = portionSize;
    }
     /**
     * Gets the name of the food item.
     *
     * @return the name of the food item
     */
    public String getName() {
        return name;
    }
     /**
     * Gets the price of the food item.
     *
     * @return the price of the food item
     */
    public double getPrice() {
        return price;
    }
    /**
     * Gets the quantity of the food item.
     *
     * @return the quantity of the food item
     */
    public int getQuantity() {
        return Quantity;
    }
    /**
     * Gets the Ingredients of the food item.
     *
     * @return the Ingredients of the food item
     */
    public String getIngredients() {
        return Ingredients;
    }
    /**
     * Gets the Calorie of the food item.
     *
     * @return the Calorie of the food item
     */
    public int getCalorie() {
        return Calorie;
    }
    /**
     * Gets the IsVegetrain of the food item.
     *
     * @return the IsVegetrain of the food item
     */
    public Boolean getIsVegetrain() {
        return IsVegetrain;
    }
    /**
     * Gets the CustomAdd of the food item.
     *
     * @return the CustomAdd of the food item
     */
    public String getCustomAdd() {
        return CustomAdd;
    }
    /**
     * Gets the portionSize of the food item.
     *
     * @return the portionSize of the food item
     */
    public String getPortionSize() {
        return portionSize;
    }
    /**
     * Sets the name of the food item.
     *
     * @param name the new name of the food item
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * Sets the price of the food item.
     *
     * @param price the new name of the food item
     */
    public void setPrice(double price) {
        this.price = price;
    }
        /**
     * Sets the Quantity of the food item.
     *
     * @param Quantity the new name of the food item
     */
    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }
        /**
     * Sets the Ingredients of the food item.
     *
     * @param Ingredients the new name of the food item
     */
    public void setIngredients(String Ingredients) {
        this.Ingredients = Ingredients;
    }
    /**
     * Sets the Calorie of the food item.
     *
     * @param Calorie the new name of the food item
     */
    public void setCalorie(int Calorie) {
        this.Calorie = Calorie;
    }
    /**
     * Sets the IsVegetrain of the food item.
     *
     * @param IsVegetrain the new name of the food item
     */
    public void setIsVegetrain(Boolean IsVegetrain) {
        this.IsVegetrain = IsVegetrain;
    }
    /**
     * Sets the CustomAdd of the food item.
     *
     * @param CustomAdd the new name of the food item
     */
    public void setCustomAdd(String CustomAdd) {
        this.CustomAdd = CustomAdd;
    }
    /**
     * Sets the portionSize of the food item.
     *
     * @param portionSize the new name of the food item
     */
    public void setPortionSize(String portionSize) {
        this.portionSize = portionSize;
    }    
}
