/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Foodie.util;

import javax.swing.JOptionPane;

/**
 *
 * @author 23028573_ArchanaGiri
 */
public class validationUtil {
    /** 
    *Validates if the quantity is greater than zero.
    * @param qty the quantity to validate 
    * @return true if valid, false otherwise
    */
    public static boolean isQuantityValid(int qty){
        if(qty<0){
            JOptionPane.showMessageDialog(null, "Quantity must be greater than zero.", "Invalid Quantity", JOptionPane.WARNING_MESSAGE );
            return false;
        }
        return true;
    }
     /**
     * Validates if the input string is empty.
     * @param input the string to validate
     * @param fieldName the name of the field for error message
     * @return true if valid, false otherwise
     */
    public static boolean isInputValid(String input, String fieldName) {
        if (input == null || input.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, fieldName + " cannot be empty.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
     /**
     * Validates if the selected row in the table is valid.
     * @param selectedRow the index of the selected row
     * @return true if a row is selected, false otherwise
     */
    public static boolean isRowSelected(int selectedRow) {
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a food item.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}
