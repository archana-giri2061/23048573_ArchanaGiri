/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.foodie.view;
// Import necessary classes and packages
import com.Foodie.Controllers.algorithms.InsertSort;
import com.Foodie.Controllers.algorithms.MergeSort;
import com.Foodie.Controllers.algorithms.SelectionSort;
import com.Foodie.Controllers.algorithms.BinarySearch;
import com.Foodie.Controllers.calculateBills;
import com.Foodie.util.validationUtil;
import com.Foodie.model.food;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.util.LinkedList;
import java.util.List;
/**
 *  Main class for the Food Order application.
 * Handles the GUI and core functionality for food ordering, billing, and navigation.
 * 
 * @author 23028573_ArchanaGiri
 */
public class foodOrder extends javax.swing.JFrame {
    // Class variables declaration
    private CardLayout cardLayout; //For switching between different screens
    private LinkedList<food> billList;  // List to store food items added to the bill
    private DefaultTableModel billTableModel;  // Model for managing table data
    private calculateBills controller;  // Controller for bill calculations
    // Sorting and searching algorithms
    private final SelectionSort selectionSort;
    private final InsertSort InsertSort;
    private final MergeSort MergeSort;
    private final BinarySearch BinarySearch;
    /**
     * Constructor for the foodOrder class. Initializes components and data.
     */
    public foodOrder() {
     /**
      * Initialize GUI components
      * Initialize the bill list
      * set the current time on the interface
      * load initial food data
      * Start the loading progress bar
      */
        initComponents();
        billList = new LinkedList<>();
        controller = new calculateBills();
        setTime();
        AddLayout();
        AddData();
        startProgress();
        updateTotals();
        // Initialize sorting and searching algorithms
        selectionSort = new SelectionSort();
        InsertSort = new InsertSort();
        MergeSort = new MergeSort();
        BinarySearch = new BinarySearch();
        
    }
    /**
     * Returns the current list of food items in the bill.
     * @return LinkedList of food items
     */
    public LinkedList<food> getBillList() {
        return billList;
    }
    /**
     * Validates if the quantity of an item is greater than zero.
     * @param qty Quantity of the item
     * @return true if valid, false otherwise
     */
    public boolean qtyIsZero(int qty) {
        if (qty == 0) {
            JOptionPane.showMessageDialog(null, "Item Quantity is not added", "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
            return false;
        }
        return true;
    }
     /**
     * Initializes the card layout for screen navigation.
     */
    private void AddLayout() {
        cardLayout = new java.awt.CardLayout();
        getContentPane().setLayout(cardLayout);
        
        // Add different screens to the layout
        getContentPane().add(loadingPage, "loadingScreen");
        getContentPane().add(login, "LoginScreen");
        getContentPane().add(dashboard, "MainScreen");

        loadScreen("loadingScreen"); // Display the loading screen initially
    }
     /**
     * Loads initial food data into the application.
     */
    private void AddData() {
        billList = new LinkedList<>();// Initialize the bill list
        // Add sample food items to the list
        billList.add(new food("Pizza", 850.0, 0, "Tomato, Onion, Cheese", 250, false, "Extra Cheese", "Medium"));
        billList.add(new food("burger", 500.0, 0, "Chicken, Onion, Tomato, Cheese", 300, false, "Extra Patty", "Large"));
        billList.add(new food("Spaghetti", 750.0, 0, "Noodles, White cheese", 400, true, "Extra Sauce", "Small"));
        billList.add(new food("Mo:Mo", 250.0, 0, "cabbagge, Onion, Chicken", 200, false, "Extra Chilli Sauce", "Small"));
        billList.add(new food("Fried Rice", 400.0, 0, "Tomato, Onion, Cheese", 350, true, "Add Egg", "Large"));
        
        loadListToTable(billList);// Add sample food items to the list
    }
     /**
     * Loads a list of food items into the table.
     * @param billList List of food items
     */
    private void loadListToTable(List<food> billList){
        DefaultTableModel model = (DefaultTableModel) billTable.getModel();
        model.setRowCount(0);// Clear existing rows
        // Add each food item to the table
        billList.forEach(food -> model.addRow(new Object[]{
            food.getName(),
            food.getPrice(),
            food.getQuantity(),
            food.getIngredients(),
            food.getCalorie(),
            food.getIsVegetrain(),
            food.getCustomAdd(),
            food.getPortionSize()
        }));
    }
        /**
     * Adds a new food item to the bill and updates the table.D
     * @param bill Food item to add
     */
    private void billing(food bill) {
        if(!validationUtil.isQuantityValid(bill.getQuantity())){
            return;
        }
        billList.add(bill);// Add the item to the bill list
        DefaultTableModel model = (DefaultTableModel) billTable.getModel();
        // Add the item to the table
        model.addRow(new Object[]{bill.getName(),
            bill.getPrice(),
            bill.getQuantity(),
            bill.getIngredients(),
            bill.getCalorie(),
            bill.getIsVegetrain(),
            bill.getCustomAdd(),
            bill.getPortionSize()
        });
    }
     /**
     * Starts the loading progress bar and transitions to the login screen.
     */
    private void startProgress() {
        javax.swing.SwingWorker<Void, Integer> worker = new javax.swing.SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                for (int i = 0; i <= 100; i++) {
                    Thread.sleep(30);
                    publish(i);  // Publish progress value
                }
                return null;
            }

            @Override
            protected void process(java.util.List<Integer> chunks) {
                // Update progress bar value
                int progress = chunks.get(chunks.size() - 1);
                loading.setValue(progress);  // Update the loading progress bar
            }

            @Override
            protected void done() {
                loadScreen("LoginScreen"); // Switch to login screen or other actions after progress is complete
            }
        };
        worker.execute();  // Start the worker thread
    }
    /**
     * Resets all input fields and selections to their default state.
     */
    public void reset(){
        //reset Spinners to 0
        food1Spinner.setValue(0);
        food2Spinner.setValue(0);
        food3Spinner.setValue(0);
        food4Spinner.setValue(0);
        food5Spinner.setValue(0);
        food6Spinner.setValue(0);
        food7Spinner.setValue(0);
        food8Spinner.setValue(0);
        
        //reset text field to default values
        subTotalTextField.setText("0.0");
        itemTextField.setText("0.0");
        totalTextField.setText("0.0");
        
        // Uncheck all checkboxes
        food1Checkbox.setSelected(false);
        food2checkbox.setSelected(false);
        food3Checkbox.setSelected(false);
        food4checkbox.setSelected(false);
        food5Checkbox.setSelected(false);
        food6Checkbox.setSelected(false);
        food7Checkbox.setSelected(false);
        food8Checkbox.setSelected(false);
        
        // Clear the date field
        billDate.setText("");
    }
    /**
    * Updates the totals displayed in the user interface.
    * 
    * This method calculates the total quantity of items ordered, the subtotal,
    * tax, and final total price for the items in the bill table. It then updates
    * the corresponding text fields in the UI with these calculated values.
    */
    private void updateTotals(){
        // Retrieve the table model associated with the bill table
        DefaultTableModel model = (DefaultTableModel) billTable.getModel();
        // Initialize variables to track the total quantity and subtotal
        int totalQuantity = 0;
        double subtotal = 0.0;
        // Loop through all rows in the table to calculate totals
        for(int i=0; i<model.getRowCount(); i++){
            // Get the quantity and price of the current item from the table
            int quantity = (int) model.getValueAt(i,2);
            double price = (double) model.getValueAt(i, 1);
            
        // Only include items with a quantity greater than 0 in the calculations
            if(quantity >0){
                totalQuantity += quantity;
                subtotal += quantity *price;
            }
        }
        // Calculate the tax and totalPrice based on the subtotal using the controller
        double tax = controller.calculateTax(subtotal);
        double totalPrice = controller.calculateFinalTotal(subtotal, tax);
        // Update the UI components with the calculated values
        itemTextField.setText(String.valueOf(totalQuantity));
        subTotalTextField.setText(String.format("%.2f", subtotal));
        taxTextField.setText(String.format("%2f", tax));
        totalTextField.setText(String.format("%2f", totalPrice));
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        loadingPage = new javax.swing.JPanel();
        loadingPageImage1 = new javax.swing.JLabel();
        loading = new javax.swing.JProgressBar();
        welcomeText1 = new javax.swing.JLabel();
        welcomeText2 = new javax.swing.JLabel();
        welcomeText3 = new javax.swing.JLabel();
        welcomeText4 = new javax.swing.JLabel();
        welcomeText5 = new javax.swing.JLabel();
        login = new javax.swing.JPanel();
        loginDetails = new javax.swing.JPanel();
        loginText = new javax.swing.JLabel();
        userField = new javax.swing.JTextField();
        userText = new javax.swing.JLabel();
        passwordField = new javax.swing.JPasswordField();
        PasswordText = new javax.swing.JLabel();
        loginButton = new javax.swing.JButton();
        cancleButton = new javax.swing.JButton();
        loginImage = new javax.swing.JLabel();
        dashboard = new javax.swing.JPanel();
        logopanel = new javax.swing.JPanel();
        dateTime = new javax.swing.JLabel();
        dateTime1 = new javax.swing.JLabel();
        NavImage = new javax.swing.JLabel();
        menu = new javax.swing.JPanel();
        menuField = new javax.swing.JPanel();
        food2 = new javax.swing.JPanel();
        food2Name = new javax.swing.JLabel();
        food2Price = new javax.swing.JLabel();
        food2Quantity = new javax.swing.JLabel();
        food2Purchase = new javax.swing.JLabel();
        food2Pizza = new javax.swing.JLabel();
        food2P = new javax.swing.JLabel();
        food2checkbox = new javax.swing.JCheckBox();
        food2Image = new javax.swing.JLabel();
        food2Spinner = new javax.swing.JSpinner();
        food3 = new javax.swing.JPanel();
        food3Name = new javax.swing.JLabel();
        food3Price = new javax.swing.JLabel();
        food3Quantity = new javax.swing.JLabel();
        food3Purchase = new javax.swing.JLabel();
        food3MoMo = new javax.swing.JLabel();
        food3P = new javax.swing.JLabel();
        food3Spinner = new javax.swing.JSpinner();
        food3Checkbox = new javax.swing.JCheckBox();
        food3Image = new javax.swing.JLabel();
        food4 = new javax.swing.JPanel();
        food4Name = new javax.swing.JLabel();
        food4Price = new javax.swing.JLabel();
        food4Qunatity = new javax.swing.JLabel();
        food4Purchase = new javax.swing.JLabel();
        food4Pasta = new javax.swing.JLabel();
        food4P = new javax.swing.JLabel();
        food4Spinner = new javax.swing.JSpinner();
        food4checkbox = new javax.swing.JCheckBox();
        food4Image = new javax.swing.JLabel();
        food5 = new javax.swing.JPanel();
        food5Name = new javax.swing.JLabel();
        food5Price = new javax.swing.JLabel();
        food5Quantity = new javax.swing.JLabel();
        food5Purchase = new javax.swing.JLabel();
        food5Spaghetti = new javax.swing.JLabel();
        food5P = new javax.swing.JLabel();
        food5Spinner = new javax.swing.JSpinner();
        food5Checkbox = new javax.swing.JCheckBox();
        food5Image = new javax.swing.JLabel();
        food1 = new javax.swing.JPanel();
        food1Name = new javax.swing.JLabel();
        food1Price = new javax.swing.JLabel();
        food1Quantity = new javax.swing.JLabel();
        food1Purchase = new javax.swing.JLabel();
        food1Burger = new javax.swing.JLabel();
        food1P = new javax.swing.JLabel();
        food1Spinner = new javax.swing.JSpinner();
        food1Checkbox = new javax.swing.JCheckBox();
        food1Image = new javax.swing.JLabel();
        food6 = new javax.swing.JPanel();
        food6Name = new javax.swing.JLabel();
        food6Price = new javax.swing.JLabel();
        food6Quantity = new javax.swing.JLabel();
        food6Purchase = new javax.swing.JLabel();
        food6Sandwich = new javax.swing.JLabel();
        food6P = new javax.swing.JLabel();
        food6Checkbox = new javax.swing.JCheckBox();
        food6Spinner = new javax.swing.JSpinner();
        food6Image = new javax.swing.JLabel();
        food8 = new javax.swing.JPanel();
        food8Name = new javax.swing.JLabel();
        food8Price = new javax.swing.JLabel();
        food8Quantity = new javax.swing.JLabel();
        food8Chicken = new javax.swing.JLabel();
        food8Purchase = new javax.swing.JLabel();
        food8P = new javax.swing.JLabel();
        food8Spinner = new javax.swing.JSpinner();
        food8Checkbox = new javax.swing.JCheckBox();
        food8Image = new javax.swing.JLabel();
        food7 = new javax.swing.JPanel();
        food7Name = new javax.swing.JLabel();
        food7Price = new javax.swing.JLabel();
        food7Quantity = new javax.swing.JLabel();
        food7Purchase = new javax.swing.JLabel();
        food7Friedrice = new javax.swing.JLabel();
        food7P = new javax.swing.JLabel();
        food7Spinner = new javax.swing.JSpinner();
        food7Checkbox = new javax.swing.JCheckBox();
        food7Image = new javax.swing.JLabel();
        menuText = new javax.swing.JLabel();
        footerPanel = new javax.swing.JPanel();
        deleteButton = new javax.swing.JButton();
        resetButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        billButton1 = new javax.swing.JButton();
        UpdateButton = new javax.swing.JButton();
        FinalBill = new javax.swing.JPanel();
        itemTextField = new javax.swing.JTextField();
        totalTextField = new javax.swing.JTextField();
        items = new javax.swing.JLabel();
        tax = new javax.swing.JLabel();
        subTotal = new javax.swing.JLabel();
        totalPrice1 = new javax.swing.JLabel();
        sorting1 = new javax.swing.JButton();
        sorting2 = new javax.swing.JButton();
        sorting3 = new javax.swing.JButton();
        subTotalTextField = new javax.swing.JTextField();
        taxTextField = new javax.swing.JTextField();
        billDetails = new javax.swing.JPanel();
        billTextfield = new javax.swing.JScrollPane();
        billTable = new javax.swing.JTable();
        timeTextfield = new javax.swing.JScrollPane();
        billDate = new javax.swing.JTextArea();
        SearchTextField = new javax.swing.JTextField();
        SearchButton = new javax.swing.JButton();

        loadingPage.setBackground(new java.awt.Color(255, 255, 255));
        loadingPage.setMaximumSize(new java.awt.Dimension(1920, 1080));
        loadingPage.setMinimumSize(new java.awt.Dimension(1920, 1080));
        loadingPage.setPreferredSize(new java.awt.Dimension(1920, 1080));
        loadingPage.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        loadingPageImage1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/logo.png"))); // NOI18N
        loadingPageImage1.setText("jLabel3");
        loadingPage.add(loadingPageImage1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 0, 420, 360));
        loadingPage.add(loading, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 820, 1150, 20));

        welcomeText1.setFont(new java.awt.Font("Times New Roman", 0, 50)); // NOI18N
        welcomeText1.setForeground(new java.awt.Color(255, 153, 0));
        welcomeText1.setText("Welcome to FoodieGo!");
        loadingPage.add(welcomeText1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 360, 560, 80));

        welcomeText2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        welcomeText2.setForeground(new java.awt.Color(255, 153, 0));
        welcomeText2.setText("Hungry? ");
        loadingPage.add(welcomeText2, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 450, 200, 40));

        welcomeText3.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        welcomeText3.setForeground(new java.awt.Color(255, 153, 0));
        welcomeText3.setText("Tap to treat yourself today!");
        loadingPage.add(welcomeText3, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 620, -1, -1));

        welcomeText4.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        welcomeText4.setForeground(new java.awt.Color(255, 153, 0));
        welcomeText4.setText(" We’ve got meals for every mood and every crew!");
        loadingPage.add(welcomeText4, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 510, -1, -1));

        welcomeText5.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        welcomeText5.setForeground(new java.awt.Color(255, 153, 0));
        welcomeText5.setText("Quick, easy, and oh-so-delicious");
        loadingPage.add(welcomeText5, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 570, -1, -1));

        login.setBackground(new java.awt.Color(228, 176, 32));
        login.setMaximumSize(new java.awt.Dimension(1920, 1080));
        login.setMinimumSize(new java.awt.Dimension(1920, 1080));
        login.setPreferredSize(new java.awt.Dimension(1920, 1080));

        loginDetails.setBackground(new java.awt.Color(62, 126, 166));
        loginDetails.setMaximumSize(new java.awt.Dimension(800, 700));
        loginDetails.setMinimumSize(new java.awt.Dimension(800, 700));
        loginDetails.setPreferredSize(new java.awt.Dimension(800, 700));

        loginText.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        loginText.setForeground(new java.awt.Color(255, 255, 255));
        loginText.setText("Login Account");

        userField.setToolTipText("Username");
        userField.setMaximumSize(new java.awt.Dimension(64, 22));

        userText.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        userText.setForeground(new java.awt.Color(255, 255, 255));
        userText.setText("Username");

        passwordField.setMaximumSize(new java.awt.Dimension(64, 22));

        PasswordText.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        PasswordText.setForeground(new java.awt.Color(255, 255, 255));
        PasswordText.setText("Password");

        loginButton.setBackground(new java.awt.Color(0, 102, 102));
        loginButton.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        loginButton.setForeground(new java.awt.Color(255, 255, 255));
        loginButton.setText("Login");
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });

        cancleButton.setBackground(new java.awt.Color(0, 102, 102));
        cancleButton.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        cancleButton.setForeground(new java.awt.Color(255, 255, 255));
        cancleButton.setText("Cancel");
        cancleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancleButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout loginDetailsLayout = new javax.swing.GroupLayout(loginDetails);
        loginDetails.setLayout(loginDetailsLayout);
        loginDetailsLayout.setHorizontalGroup(
            loginDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, loginDetailsLayout.createSequentialGroup()
                .addContainerGap(221, Short.MAX_VALUE)
                .addGroup(loginDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(loginText, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userText)
                    .addComponent(userField, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PasswordText)
                    .addGroup(loginDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cancleButton, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(316, 316, 316))
        );
        loginDetailsLayout.setVerticalGroup(
            loginDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginDetailsLayout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(loginText, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addComponent(userText)
                .addGap(18, 18, 18)
                .addComponent(userField, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(PasswordText)
                .addGap(18, 18, 18)
                .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(cancleButton, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(180, Short.MAX_VALUE))
        );

        loginImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/signIn.png"))); // NOI18N

        javax.swing.GroupLayout loginLayout = new javax.swing.GroupLayout(login);
        login.setLayout(loginLayout);
        loginLayout.setHorizontalGroup(
            loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(loginImage)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(loginDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(248, Short.MAX_VALUE))
        );
        loginLayout.setVerticalGroup(
            loginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(loginImage))
            .addGroup(loginLayout.createSequentialGroup()
                .addGap(157, 157, 157)
                .addComponent(loginDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1920, 1080));
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        setPreferredSize(new java.awt.Dimension(1920, 1080));
        setSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dashboard.setBackground(new java.awt.Color(250, 250, 250));
        dashboard.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        dashboard.setMaximumSize(new java.awt.Dimension(1920, 1080));
        dashboard.setMinimumSize(new java.awt.Dimension(1920, 1080));
        dashboard.setPreferredSize(new java.awt.Dimension(1920, 1080));
        dashboard.setVerifyInputWhenFocusTarget(false);
        dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logopanel.setBackground(new java.awt.Color(228, 176, 32));
        logopanel.setMaximumSize(new java.awt.Dimension(1910, 85));
        logopanel.setMinimumSize(new java.awt.Dimension(1910, 85));
        logopanel.setPreferredSize(new java.awt.Dimension(1910, 85));

        dateTime.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N

        dateTime1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N

        NavImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/logo3.png"))); // NOI18N

        javax.swing.GroupLayout logopanelLayout = new javax.swing.GroupLayout(logopanel);
        logopanel.setLayout(logopanelLayout);
        logopanelLayout.setHorizontalGroup(
            logopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logopanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(NavImage, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1276, Short.MAX_VALUE)
                .addComponent(dateTime, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(dateTime1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );
        logopanelLayout.setVerticalGroup(
            logopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logopanelLayout.createSequentialGroup()
                .addGroup(logopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(logopanelLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(logopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dateTime, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dateTime1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(logopanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(NavImage, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        dashboard.add(logopanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 2, 1910, 100));

        menu.setBackground(new java.awt.Color(228, 176, 32));
        menu.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(240, 240, 240), 2, true));
        menu.setMaximumSize(new java.awt.Dimension(970, 750));
        menu.setMinimumSize(new java.awt.Dimension(970, 750));
        menu.setPreferredSize(new java.awt.Dimension(970, 750));
        menu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuField.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        menu.add(menuField, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 56, -1, -1));

        food2.setBackground(new java.awt.Color(62, 126, 166));
        food2.setMaximumSize(new java.awt.Dimension(218, 328));
        food2.setMinimumSize(new java.awt.Dimension(218, 328));
        food2.setPreferredSize(new java.awt.Dimension(218, 328));

        food2Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food2Name.setForeground(new java.awt.Color(255, 255, 255));
        food2Name.setText("Name:");

        food2Price.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food2Price.setForeground(new java.awt.Color(255, 255, 255));
        food2Price.setText("Price:");

        food2Quantity.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food2Quantity.setForeground(new java.awt.Color(255, 255, 255));
        food2Quantity.setText("Quantity:");

        food2Purchase.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food2Purchase.setForeground(new java.awt.Color(255, 255, 255));
        food2Purchase.setText("Purchase:");

        food2Pizza.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food2Pizza.setForeground(new java.awt.Color(242, 242, 242));
        food2Pizza.setText("Pizza");

        food2P.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food2P.setForeground(new java.awt.Color(242, 242, 242));
        food2P.setText("Rs 850.0");

        food2checkbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                food2checkboxActionPerformed(evt);
            }
        });

        food2Image.setForeground(new java.awt.Color(242, 242, 242));
        food2Image.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/pizza.png"))); // NOI18N

        food2Spinner.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        food2Spinner.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));

        javax.swing.GroupLayout food2Layout = new javax.swing.GroupLayout(food2);
        food2.setLayout(food2Layout);
        food2Layout.setHorizontalGroup(
            food2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(food2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(food2Purchase)
                    .addComponent(food2Name, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food2Price, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food2Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addGroup(food2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(food2Pizza)
                    .addComponent(food2P)
                    .addComponent(food2checkbox, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food2Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 43, Short.MAX_VALUE))
            .addGroup(food2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(food2Image)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        food2Layout.setVerticalGroup(
            food2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, food2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(food2Image)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(food2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food2Name)
                    .addComponent(food2Pizza))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(food2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food2Price)
                    .addComponent(food2P))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food2Quantity)
                    .addComponent(food2Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(food2Purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food2checkbox))
                .addGap(21, 21, 21))
        );

        menu.add(food2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 100, -1, -1));

        food3.setBackground(new java.awt.Color(62, 126, 166));
        food3.setMaximumSize(new java.awt.Dimension(218, 328));
        food3.setMinimumSize(new java.awt.Dimension(218, 328));
        food3.setPreferredSize(new java.awt.Dimension(218, 328));

        food3Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food3Name.setForeground(new java.awt.Color(242, 242, 242));
        food3Name.setText("Name:");

        food3Price.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food3Price.setForeground(new java.awt.Color(242, 242, 242));
        food3Price.setText("Price:");

        food3Quantity.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food3Quantity.setForeground(new java.awt.Color(242, 242, 242));
        food3Quantity.setText("Quantity:");

        food3Purchase.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food3Purchase.setForeground(new java.awt.Color(242, 242, 242));
        food3Purchase.setText("Purchase:");

        food3MoMo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food3MoMo.setForeground(new java.awt.Color(242, 242, 242));
        food3MoMo.setText("Mo:Mo");

        food3P.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food3P.setForeground(new java.awt.Color(242, 242, 242));
        food3P.setText("Rs 250.0");

        food3Spinner.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        food3Spinner.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));

        food3Checkbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                food3CheckboxActionPerformed(evt);
            }
        });

        food3Image.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/momo.png"))); // NOI18N

        javax.swing.GroupLayout food3Layout = new javax.swing.GroupLayout(food3);
        food3.setLayout(food3Layout);
        food3Layout.setHorizontalGroup(
            food3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(food3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(food3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(food3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(food3Price, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food3Name, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food3Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food3Purchase))
                        .addGap(40, 40, 40)
                        .addGroup(food3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(food3Checkbox)
                            .addComponent(food3P)
                            .addComponent(food3MoMo)
                            .addComponent(food3Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(49, Short.MAX_VALUE))
                    .addGroup(food3Layout.createSequentialGroup()
                        .addComponent(food3Image)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        food3Layout.setVerticalGroup(
            food3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, food3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(food3Image)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(food3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food3Name)
                    .addComponent(food3MoMo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food3Price)
                    .addComponent(food3P))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food3Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food3Quantity))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(food3Checkbox, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(food3Purchase, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
        );

        menu.add(food3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 100, -1, -1));

        food4.setBackground(new java.awt.Color(62, 126, 166));
        food4.setMaximumSize(new java.awt.Dimension(218, 328));
        food4.setMinimumSize(new java.awt.Dimension(218, 328));
        food4.setPreferredSize(new java.awt.Dimension(218, 328));

        food4Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food4Name.setForeground(new java.awt.Color(242, 242, 242));
        food4Name.setText("Name:");

        food4Price.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food4Price.setForeground(new java.awt.Color(242, 242, 242));
        food4Price.setText("Price:");

        food4Qunatity.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food4Qunatity.setForeground(new java.awt.Color(242, 242, 242));
        food4Qunatity.setText("Quantity:");

        food4Purchase.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food4Purchase.setForeground(new java.awt.Color(242, 242, 242));
        food4Purchase.setText("Purchase:");

        food4Pasta.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food4Pasta.setForeground(new java.awt.Color(242, 242, 242));
        food4Pasta.setText("Pasta");

        food4P.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food4P.setForeground(new java.awt.Color(242, 242, 242));
        food4P.setText("Rs 900.0");

        food4Spinner.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        food4Spinner.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));

        food4checkbox.setBackground(new java.awt.Color(255, 255, 255));
        food4checkbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                food4checkboxActionPerformed(evt);
            }
        });

        food4Image.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/Pasta.png"))); // NOI18N

        javax.swing.GroupLayout food4Layout = new javax.swing.GroupLayout(food4);
        food4.setLayout(food4Layout);
        food4Layout.setHorizontalGroup(
            food4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food4Layout.createSequentialGroup()
                .addGroup(food4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(food4Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(food4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(food4Price, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food4Name, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food4Qunatity, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food4Purchase))
                        .addGap(40, 40, 40)
                        .addGroup(food4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(food4checkbox)
                            .addComponent(food4P)
                            .addComponent(food4Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food4Pasta, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(food4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(food4Image)))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        food4Layout.setVerticalGroup(
            food4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, food4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(food4Image)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(food4Layout.createSequentialGroup()
                        .addComponent(food4Pasta)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(food4P)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(food4Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(food4Layout.createSequentialGroup()
                        .addComponent(food4Name)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(food4Price, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(food4Qunatity)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(food4checkbox, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(food4Purchase, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26))
        );

        menu.add(food4, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 100, -1, 327));

        food5.setBackground(new java.awt.Color(62, 126, 166));
        food5.setMaximumSize(new java.awt.Dimension(218, 328));
        food5.setMinimumSize(new java.awt.Dimension(218, 328));
        food5.setPreferredSize(new java.awt.Dimension(218, 328));

        food5Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food5Name.setForeground(new java.awt.Color(255, 255, 255));
        food5Name.setText("Name:");

        food5Price.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food5Price.setForeground(new java.awt.Color(255, 255, 255));
        food5Price.setText("Price:");

        food5Quantity.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food5Quantity.setForeground(new java.awt.Color(242, 242, 242));
        food5Quantity.setText("Quantity:");

        food5Purchase.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food5Purchase.setForeground(new java.awt.Color(242, 242, 242));
        food5Purchase.setText("Purchase:");

        food5Spaghetti.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food5Spaghetti.setForeground(new java.awt.Color(255, 255, 255));
        food5Spaghetti.setText("Spaghetti");

        food5P.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food5P.setForeground(new java.awt.Color(255, 255, 255));
        food5P.setText("Rs 750.0");

        food5Spinner.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        food5Spinner.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));

        food5Checkbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                food5CheckboxActionPerformed(evt);
            }
        });

        food5Image.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/Spaghetti.png"))); // NOI18N

        javax.swing.GroupLayout food5Layout = new javax.swing.GroupLayout(food5);
        food5.setLayout(food5Layout);
        food5Layout.setHorizontalGroup(
            food5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, food5Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(food5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(food5Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food5Purchase)
                    .addComponent(food5Price, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food5Name, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(food5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(food5Spaghetti)
                    .addComponent(food5P)
                    .addComponent(food5Checkbox)
                    .addComponent(food5Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35))
            .addGroup(food5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(food5Image)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        food5Layout.setVerticalGroup(
            food5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(food5Image)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(food5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food5Spaghetti)
                    .addComponent(food5Name))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food5P)
                    .addComponent(food5Price))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food5Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food5Quantity))
                .addGap(14, 14, 14)
                .addGroup(food5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(food5Purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food5Checkbox))
                .addGap(18, 18, 18))
        );

        menu.add(food5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, -1, -1));

        food1.setBackground(new java.awt.Color(62, 126, 166));
        food1.setMaximumSize(new java.awt.Dimension(218, 328));
        food1.setMinimumSize(new java.awt.Dimension(218, 328));
        food1.setPreferredSize(new java.awt.Dimension(218, 328));

        food1Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food1Name.setForeground(new java.awt.Color(242, 242, 242));
        food1Name.setText("Name:");

        food1Price.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food1Price.setForeground(new java.awt.Color(242, 242, 242));
        food1Price.setText("Price:");

        food1Quantity.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food1Quantity.setForeground(new java.awt.Color(242, 242, 242));
        food1Quantity.setText("Quantity:");

        food1Purchase.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food1Purchase.setForeground(new java.awt.Color(242, 242, 242));
        food1Purchase.setText("Purchase:");

        food1Burger.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food1Burger.setForeground(new java.awt.Color(242, 242, 242));
        food1Burger.setText("Burger");

        food1P.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food1P.setForeground(new java.awt.Color(242, 242, 242));
        food1P.setText("Rs 500.0");

        food1Spinner.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        food1Spinner.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));

        food1Checkbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                food1CheckboxActionPerformed(evt);
            }
        });

        food1Image.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/burger.png"))); // NOI18N

        javax.swing.GroupLayout food1Layout = new javax.swing.GroupLayout(food1);
        food1.setLayout(food1Layout);
        food1Layout.setHorizontalGroup(
            food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(food1Name, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(food1Price, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(food1Purchase))
                    .addComponent(food1Quantity, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(food1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(food1Checkbox)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, food1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(food1P)
                                .addComponent(food1Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(food1Layout.createSequentialGroup()
                                .addComponent(food1Burger)
                                .addGap(27, 27, 27)))
                        .addGap(36, 36, 36))))
            .addGroup(food1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(food1Image)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        food1Layout.setVerticalGroup(
            food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(food1Image)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food1Name)
                    .addComponent(food1Burger))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food1Price)
                    .addComponent(food1P))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food1Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food1Quantity))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(food1Purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food1Checkbox))
                .addGap(16, 16, 16))
        );

        menu.add(food1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 470, -1, -1));

        food6.setBackground(new java.awt.Color(62, 126, 166));
        food6.setMaximumSize(new java.awt.Dimension(218, 328));
        food6.setMinimumSize(new java.awt.Dimension(218, 328));
        food6.setPreferredSize(new java.awt.Dimension(218, 328));

        food6Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food6Name.setForeground(new java.awt.Color(242, 242, 242));
        food6Name.setText("Name:");

        food6Price.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food6Price.setForeground(new java.awt.Color(242, 242, 242));
        food6Price.setText("Price:");

        food6Quantity.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food6Quantity.setForeground(new java.awt.Color(242, 242, 242));
        food6Quantity.setText("Quantity:");

        food6Purchase.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food6Purchase.setForeground(new java.awt.Color(242, 242, 242));
        food6Purchase.setText("Purchase:");

        food6Sandwich.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food6Sandwich.setForeground(new java.awt.Color(242, 242, 242));
        food6Sandwich.setText("Sandwich");

        food6P.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food6P.setForeground(new java.awt.Color(242, 242, 242));
        food6P.setText("Rs 350.0");

        food6Checkbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                food6CheckboxActionPerformed(evt);
            }
        });

        food6Spinner.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        food6Spinner.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));

        food6Image.setForeground(new java.awt.Color(242, 242, 242));
        food6Image.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/Sandwich.png"))); // NOI18N

        javax.swing.GroupLayout food6Layout = new javax.swing.GroupLayout(food6);
        food6.setLayout(food6Layout);
        food6Layout.setHorizontalGroup(
            food6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food6Layout.createSequentialGroup()
                .addGroup(food6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(food6Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(food6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(food6Name, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food6Price, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food6Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food6Purchase))
                        .addGap(47, 47, 47)
                        .addGroup(food6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(food6Checkbox)
                            .addComponent(food6P)
                            .addComponent(food6Sandwich)
                            .addComponent(food6Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(food6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(food6Image)))
                .addGap(0, 12, Short.MAX_VALUE))
        );
        food6Layout.setVerticalGroup(
            food6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, food6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(food6Image)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(food6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food6Name)
                    .addComponent(food6Sandwich))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(food6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food6Price)
                    .addComponent(food6P))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food6Quantity)
                    .addComponent(food6Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food6Purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food6Checkbox))
                .addGap(16, 16, 16))
        );

        menu.add(food6, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 470, -1, -1));

        food8.setBackground(new java.awt.Color(62, 126, 166));
        food8.setMaximumSize(new java.awt.Dimension(218, 328));
        food8.setMinimumSize(new java.awt.Dimension(218, 328));
        food8.setPreferredSize(new java.awt.Dimension(218, 328));

        food8Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food8Name.setForeground(new java.awt.Color(242, 242, 242));
        food8Name.setText("Name:");

        food8Price.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food8Price.setForeground(new java.awt.Color(242, 242, 242));
        food8Price.setText("Price:");

        food8Quantity.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food8Quantity.setForeground(new java.awt.Color(242, 242, 242));
        food8Quantity.setText("Quantity:");

        food8Chicken.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food8Chicken.setForeground(new java.awt.Color(242, 242, 242));
        food8Chicken.setText("Fried Chicken");

        food8Purchase.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food8Purchase.setForeground(new java.awt.Color(242, 242, 242));
        food8Purchase.setText("Purchase:");

        food8P.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food8P.setForeground(new java.awt.Color(242, 242, 242));
        food8P.setText("Rs 1200.0");

        food8Spinner.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        food8Spinner.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));

        food8Checkbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                food8CheckboxActionPerformed(evt);
            }
        });

        food8Image.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/FriedChicken.png"))); // NOI18N

        javax.swing.GroupLayout food8Layout = new javax.swing.GroupLayout(food8);
        food8.setLayout(food8Layout);
        food8Layout.setHorizontalGroup(
            food8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food8Layout.createSequentialGroup()
                .addGroup(food8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(food8Layout.createSequentialGroup()
                        .addGroup(food8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(food8Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(food8Name, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2))
                            .addComponent(food8Price, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food8Quantity, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food8Purchase, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(food8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(food8P)
                            .addComponent(food8Chicken)
                            .addComponent(food8Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food8Checkbox)))
                    .addGroup(food8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(food8Image)))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        food8Layout.setVerticalGroup(
            food8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(food8Image)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(food8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food8Name)
                    .addComponent(food8Chicken))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food8P)
                    .addComponent(food8Price))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(food8Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food8Quantity))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(food8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(food8Purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(food8Checkbox))
                .addGap(18, 18, 18))
        );

        menu.add(food8, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 470, -1, -1));

        food7.setBackground(new java.awt.Color(62, 126, 166));
        food7.setMaximumSize(new java.awt.Dimension(218, 328));
        food7.setMinimumSize(new java.awt.Dimension(218, 328));
        food7.setPreferredSize(new java.awt.Dimension(218, 328));
        food7.setRequestFocusEnabled(false);

        food7Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food7Name.setForeground(new java.awt.Color(242, 242, 242));
        food7Name.setText("Name:");

        food7Price.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food7Price.setForeground(new java.awt.Color(242, 242, 242));
        food7Price.setText("Price:");

        food7Quantity.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food7Quantity.setForeground(new java.awt.Color(242, 242, 242));
        food7Quantity.setText("Quantity:");

        food7Purchase.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food7Purchase.setForeground(new java.awt.Color(242, 242, 242));
        food7Purchase.setText("Purchase:");

        food7Friedrice.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food7Friedrice.setForeground(new java.awt.Color(242, 242, 242));
        food7Friedrice.setText("Fried Rice");

        food7P.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        food7P.setForeground(new java.awt.Color(242, 242, 242));
        food7P.setText("Rs 400.0");

        food7Spinner.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        food7Spinner.setModel(new javax.swing.SpinnerNumberModel(0, 0, 10, 1));

        food7Checkbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                food7CheckboxActionPerformed(evt);
            }
        });

        food7Image.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/Foodie/resources/FriedRice.png"))); // NOI18N

        javax.swing.GroupLayout food7Layout = new javax.swing.GroupLayout(food7);
        food7.setLayout(food7Layout);
        food7Layout.setHorizontalGroup(
            food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food7Layout.createSequentialGroup()
                .addGroup(food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(food7Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(food7Name, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(food7Price, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(food7Quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(food7Purchase))
                        .addGap(30, 30, 30)
                        .addGroup(food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(food7Checkbox)
                            .addComponent(food7Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(food7P)
                                .addComponent(food7Friedrice))))
                    .addGroup(food7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(food7Image)))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        food7Layout.setVerticalGroup(
            food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(food7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(food7Purchase, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(food7Layout.createSequentialGroup()
                        .addComponent(food7Image)
                        .addGap(18, 18, 18)
                        .addGroup(food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(food7Name, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(food7Friedrice))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(food7Price)
                            .addComponent(food7P))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(food7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(food7Quantity)
                            .addComponent(food7Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(food7Checkbox)))
                .addContainerGap())
        );

        menu.add(food7, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 470, -1, -1));

        menuText.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        menuText.setForeground(new java.awt.Color(255, 255, 255));
        menuText.setText("Menu Items");
        menu.add(menuText, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        dashboard.add(menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 103, 1080, 830));

        footerPanel.setBackground(new java.awt.Color(228, 176, 32));
        footerPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230), 2));
        footerPanel.setMaximumSize(new java.awt.Dimension(887, 50));
        footerPanel.setMinimumSize(new java.awt.Dimension(887, 50));
        footerPanel.setPreferredSize(new java.awt.Dimension(887, 50));
        footerPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        deleteButton.setBackground(new java.awt.Color(0, 102, 102));
        deleteButton.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        deleteButton.setForeground(new java.awt.Color(255, 255, 255));
        deleteButton.setText("Delete");
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        footerPanel.add(deleteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, 147, 42));

        resetButton.setBackground(new java.awt.Color(0, 102, 102));
        resetButton.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        resetButton.setForeground(new java.awt.Color(255, 255, 255));
        resetButton.setText("Reset");
        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });
        footerPanel.add(resetButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 20, 147, 42));

        exitButton.setBackground(new java.awt.Color(0, 102, 102));
        exitButton.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        exitButton.setForeground(new java.awt.Color(255, 255, 255));
        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        footerPanel.add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 20, 147, 42));

        billButton1.setBackground(new java.awt.Color(0, 102, 102));
        billButton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        billButton1.setForeground(new java.awt.Color(255, 255, 255));
        billButton1.setText("Bill");
        billButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                billButton1ActionPerformed(evt);
            }
        });
        footerPanel.add(billButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 147, 42));

        UpdateButton.setBackground(new java.awt.Color(0, 102, 102));
        UpdateButton.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        UpdateButton.setForeground(new java.awt.Color(255, 255, 255));
        UpdateButton.setText("Update");
        UpdateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateButtonActionPerformed(evt);
            }
        });
        footerPanel.add(UpdateButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 20, 147, 42));

        dashboard.add(footerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 930, 1080, 150));

        FinalBill.setBackground(new java.awt.Color(62, 126, 166));
        FinalBill.setMaximumSize(new java.awt.Dimension(760, 244));
        FinalBill.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        itemTextField.setEditable(false);
        itemTextField.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        itemTextField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        itemTextField.setText("0.0");
        FinalBill.add(itemTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 30, 165, 31));

        totalTextField.setEditable(false);
        totalTextField.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        totalTextField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        totalTextField.setText("0.0");
        FinalBill.add(totalTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 210, 165, 31));

        items.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        items.setForeground(new java.awt.Color(242, 242, 242));
        items.setText("Items:");
        FinalBill.add(items, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 93, -1));

        tax.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        tax.setForeground(new java.awt.Color(242, 242, 242));
        tax.setText("Tax:");
        FinalBill.add(tax, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, 93, 30));

        subTotal.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        subTotal.setForeground(new java.awt.Color(242, 242, 242));
        subTotal.setText("SubTotal:");
        FinalBill.add(subTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 150, 93, 30));

        totalPrice1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        totalPrice1.setForeground(new java.awt.Color(242, 242, 242));
        totalPrice1.setText("Total:");
        FinalBill.add(totalPrice1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 210, 93, 30));

        sorting1.setBackground(new java.awt.Color(0, 102, 102));
        sorting1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        sorting1.setForeground(new java.awt.Color(242, 242, 242));
        sorting1.setText("Sorting by Price");
        sorting1.setMaximumSize(new java.awt.Dimension(200, 44));
        sorting1.setMinimumSize(new java.awt.Dimension(200, 44));
        sorting1.setPreferredSize(new java.awt.Dimension(200, 44));
        sorting1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sorting1ActionPerformed(evt);
            }
        });
        FinalBill.add(sorting1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 40, -1, -1));

        sorting2.setBackground(new java.awt.Color(0, 102, 102));
        sorting2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        sorting2.setForeground(new java.awt.Color(242, 242, 242));
        sorting2.setText("Sorting By Name");
        sorting2.setMaximumSize(new java.awt.Dimension(200, 44));
        sorting2.setMinimumSize(new java.awt.Dimension(200, 44));
        sorting2.setPreferredSize(new java.awt.Dimension(200, 44));
        sorting2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sorting2ActionPerformed(evt);
            }
        });
        FinalBill.add(sorting2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 120, -1, -1));

        sorting3.setBackground(new java.awt.Color(0, 102, 102));
        sorting3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        sorting3.setForeground(new java.awt.Color(242, 242, 242));
        sorting3.setText("Sorting By Calorie");
        sorting3.setMaximumSize(new java.awt.Dimension(200, 44));
        sorting3.setMinimumSize(new java.awt.Dimension(200, 44));
        sorting3.setPreferredSize(new java.awt.Dimension(200, 44));
        sorting3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sorting3ActionPerformed(evt);
            }
        });
        FinalBill.add(sorting3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 200, -1, -1));

        subTotalTextField.setEditable(false);
        subTotalTextField.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        subTotalTextField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        subTotalTextField.setText("0.0");
        FinalBill.add(subTotalTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 150, 165, 31));

        taxTextField.setEditable(false);
        taxTextField.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        taxTextField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        taxTextField.setText("0.0");
        FinalBill.add(taxTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 90, 165, 31));

        dashboard.add(FinalBill, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 760, 840, 320));

        billDetails.setBackground(new java.awt.Color(62, 126, 166));
        billDetails.setMaximumSize(new java.awt.Dimension(840, 650));
        billDetails.setMinimumSize(new java.awt.Dimension(840, 650));

        billTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Price", "Quantity", "Ingredients", "Calorie", "IsVegetrain", "CustomAdd", "portionSize"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Boolean.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        billTextfield.setViewportView(billTable);

        billDate.setColumns(20);
        billDate.setRows(5);
        timeTextfield.setViewportView(billDate);

        SearchButton.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        SearchButton.setText("Search");
        SearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout billDetailsLayout = new javax.swing.GroupLayout(billDetails);
        billDetails.setLayout(billDetailsLayout);
        billDetailsLayout.setHorizontalGroup(
            billDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billDetailsLayout.createSequentialGroup()
                .addContainerGap(439, Short.MAX_VALUE)
                .addComponent(SearchTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(SearchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
            .addComponent(timeTextfield)
            .addGroup(billDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(billDetailsLayout.createSequentialGroup()
                    .addComponent(billTextfield, javax.swing.GroupLayout.DEFAULT_SIZE, 834, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        billDetailsLayout.setVerticalGroup(
            billDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(billDetailsLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(billDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SearchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SearchTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(timeTextfield, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(482, Short.MAX_VALUE))
            .addGroup(billDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, billDetailsLayout.createSequentialGroup()
                    .addContainerGap(170, Short.MAX_VALUE)
                    .addComponent(billTextfield, javax.swing.GroupLayout.PREFERRED_SIZE, 474, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        dashboard.add(billDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 110, 840, 650));

        getContentPane().add(dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1930, 1040));

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Action listener for the Reset button.
     * Resets the form to its default state.
     * 
     * @param evt the event generated when the button is clicked
     */
    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetButtonActionPerformed
        reset(); // Call the reset method to reset the form
    }//GEN-LAST:event_resetButtonActionPerformed
    /**
     * Action listener for the Exit button.
     * Exits the application.
     *
     * @param evt the event generated when the button is clicked
     */
    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        System.exit(0);// Terminate the application   
    }//GEN-LAST:event_exitButtonActionPerformed
    /**
     * Action listener for a checkbox (jCheckBox1).
     * Validates the quantity selected using a spinner.
     *
     * @param evt the event generated when the checkbox is clicked
     */
    private void food1CheckboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_food1CheckboxActionPerformed
        if (food1Checkbox.isSelected()) { // Check if another checkbox is selected
            foodie(); 
            try {
                // Get the quantity from the spinner
                int quantity = Integer.parseInt(food1Spinner.getValue().toString());

                // Check if quantity is valid
                if (quantity > 0) {
                    // Example food details
                    String name = "Burger";
                    double price = 500.0;
                    String ingredients = "Chicken, Tomato, Onion, Sauses";
                    int calories = 300;
                    boolean isVegetarian = false;
                    String customAdd = "Extra Cheese";
                    String portionSize = "Medium";

                    // Add details to the table
                    DefaultTableModel model = (DefaultTableModel) billTable.getModel();
                    boolean foodExists = false;
                    for(int i=0; i<model.getRowCount(); i++){
                        if(model.getValueAt(i, 0).equals(name)){
                            model.setValueAt(quantity, i, 2);
                            foodExists = true;
                            break;
                        }
                    }
                    if(!foodExists){
                        model.addRow(new Object[]{name, price, quantity, ingredients, calories, isVegetarian, customAdd, portionSize});
                    }
                    for(int i = model.getRowCount() -1; i>=0; i--){
                        if((int)model.getValueAt(i, 2)== 0){
                        model.removeRow(i);
                        }
                    }
                    updateTotals();
                } else {
                    // Show a message box if quantity is zero
                    JOptionPane.showMessageDialog(null, "Please select a valid quantity.", "Invalid Quantity", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                // Show a message box if quantity is invalid
                JOptionPane.showMessageDialog(null, "Invalid quantity entered. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            DefaultTableModel model = (DefaultTableModel) billTable.getModel();
            String name = "Burger";
            for(int i=0; i<model.getRowCount(); i++){
                if(model.getValueAt(i, 0).equals(name)){
                    model.removeRow(i);
                    break;
                }
            }
            updateTotals(); 
        }
    }//GEN-LAST:event_food1CheckboxActionPerformed
    /**
     * Action listener for checkbox (jCheckBox5).
     * Similar functionality to jCheckBox1.
     *
     * @param evt the event generated when the checkbox is clicked
     */
    private void food5CheckboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_food5CheckboxActionPerformed
        if (food5Checkbox.isSelected()) { // Check if another checkbox is selected
            foodie(); 
            try {
                // Get the quantity from the spinner
                int quantity = Integer.parseInt(food5Spinner.getValue().toString());

                // Check if quantity is valid
                if (quantity > 0) {
                    // Example food details
                    String name = "Spaghetti";
                    double price = 750.0;
                    String ingredients = "Noodles, Chicken, White Sauses";
                    int calories = 400;
                    boolean isVegetarian = false;
                    String customAdd = "Extra Cheese";
                    String portionSize = "Small";

                    // Add details to the table
                    DefaultTableModel model = (DefaultTableModel) billTable.getModel();
                    boolean foodExists = false;
                    for(int i=0; i<model.getRowCount(); i++){
                        if(model.getValueAt(i, 0).equals(name)){
                            model.setValueAt(quantity, i, 2);
                            foodExists = true;
                            break;
                        }
                    }
                    if(!foodExists){
                        model.addRow(new Object[]{name, price, quantity, ingredients, calories, isVegetarian, customAdd, portionSize});
                    }
                    for(int i = model.getRowCount() -1; i>=0; i--){
                        if((int)model.getValueAt(i, 2)== 0){
                        model.removeRow(i);
                        }
                    }
                    updateTotals(); 
                } else {
                    // Show a message box if quantity is zero
                    JOptionPane.showMessageDialog(null, "Please select a valid quantity.", "Invalid Quantity", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                // Show a message box if quantity is invalid
                JOptionPane.showMessageDialog(null, "Invalid quantity entered. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            DefaultTableModel model = (DefaultTableModel) billTable.getModel();
            String name = "Spaghetti";
            for(int i=0; i<model.getRowCount(); i++){
                if(model.getValueAt(i, 0).equals(name)){
                    model.removeRow(i);
                    break;
                }
            }
            updateTotals();
        }
    }//GEN-LAST:event_food5CheckboxActionPerformed
     /**
     * Action listener for checkbox (jCheckBox5).
     * Similar functionality to jCheckBox1.
     *
     * @param evt the event generated when the checkbox is clicked
     */
    private void food2checkboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_food2checkboxActionPerformed
        if (food2checkbox.isSelected()) { // Check if another checkbox is selected
            foodie(); 
            try {
                // Get the quantity from the spinner
                int quantity = Integer.parseInt(food2Spinner.getValue().toString());

                // Check if quantity is valid
                if (quantity > 0) {
                    // Example food details
                    String name = "Pizza";
                    double price = 850.0;
                    String ingredients = "Tomato, Onion, Cheese, Olive, Panner";
                    int calories = 250;
                    boolean isVegetarian = true;
                    String customAdd = "Extra Cheese";
                    String portionSize = "Medium";

                    // Add details to the table
                    DefaultTableModel model = (DefaultTableModel) billTable.getModel();
                    boolean foodExists = false;
                    for(int i=0; i<model.getRowCount(); i++){
                        if(model.getValueAt(i, 0).equals(name)){
                            model.setValueAt(quantity, i, 2);
                            foodExists = true;
                            break;
                        }
                    }
                    if(!foodExists){
                        model.addRow(new Object[]{name, price, quantity, ingredients, calories, isVegetarian, customAdd, portionSize});
                    }
                    for(int i = model.getRowCount() -1; i>=0; i--){
                        if((int)model.getValueAt(i, 2)== 0){
                        model.removeRow(i);
                        }
                    }
                    updateTotals(); 
                } else {
                    // Show a message box if quantity is zero
                    JOptionPane.showMessageDialog(null, "Please select a valid quantity.", "Invalid Quantity", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                // Show a message box if quantity is invalid
                JOptionPane.showMessageDialog(null, "Invalid quantity entered. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            DefaultTableModel model = (DefaultTableModel) billTable.getModel();
            String name = "Burger";
            for(int i=0; i<model.getRowCount(); i++){
                if(model.getValueAt(i, 0).equals(name)){
                    model.removeRow(i);
                    break;
                }
            }
            updateTotals(); 
        }
    }//GEN-LAST:event_food2checkboxActionPerformed
    /**
     * Action listener for checkbox (jCheckBox5).
     * Similar functionality to jCheckBox1.
     *
     * @param evt the event generated when the checkbox is clicked
     */
    private void food3CheckboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_food3CheckboxActionPerformed
        if (food3Checkbox.isSelected()) { // Check if another checkbox is selected
            foodie(); 
            try {
                // Get the quantity from the spinner
                int quantity = Integer.parseInt(food3Spinner.getValue().toString());

                // Check if quantity is valid
                if (quantity > 0) {
                    // Example food details
                    String name = "Mo:Mo";
                    double price = 250.0;
                    String ingredients = "Chicken, onion";
                    int calories = 200;
                    boolean isVegetarian = false;
                    String customAdd = " ";
                    String portionSize = "Full";

                    // Add details to the table
                    DefaultTableModel model = (DefaultTableModel) billTable.getModel();
                    boolean foodExists = false;
                    for(int i=0; i<model.getRowCount(); i++){
                        if(model.getValueAt(i, 0).equals(name)){
                            model.setValueAt(quantity, i, 2);
                            foodExists = true;
                            break;
                        }
                    }
                    if(!foodExists){
                        model.addRow(new Object[]{name, price, quantity, ingredients, calories, isVegetarian, customAdd, portionSize});
                    }
                    for(int i = model.getRowCount() -1; i>=0; i--){
                        if((int)model.getValueAt(i, 2)== 0){
                        model.removeRow(i);
                        }
                    }
                    updateTotals(); 
                } else {
                    // Show a message box if quantity is zero
                    JOptionPane.showMessageDialog(null, "Please select a valid quantity.", "Invalid Quantity", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                // Show a message box if quantity is invalid
                JOptionPane.showMessageDialog(null, "Invalid quantity entered. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            DefaultTableModel model = (DefaultTableModel) billTable.getModel();
            String name = "Burger";
            for(int i=0; i<model.getRowCount(); i++){
                if(model.getValueAt(i, 0).equals(name)){
                    model.removeRow(i);
                    break;
                }
            }
            updateTotals();
        }
    }//GEN-LAST:event_food3CheckboxActionPerformed
   /**
     * Action listener for checkbox (jCheckBox5).
     * Similar functionality to jCheckBox1.
     *
     * @param evt the event generated when the checkbox is clicked
     */
    private void food4checkboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_food4checkboxActionPerformed
        if (food4checkbox.isSelected()) { // Check if another checkbox is selected
            foodie(); 
            try {
                // Get the quantity from the spinner
                int quantity = Integer.parseInt(food4Spinner.getValue().toString());

                // Check if quantity is valid
                if (quantity > 0) {
                    // Example food details
                    String name = "Pasta";
                    double price = 900.0;
                    String ingredients = "Pasta, White Sause";
                    int calories = 500;
                    boolean isVegetarian = true;
                    String customAdd = "Extra Cheese";
                    String portionSize = "Half";

                    // Add details to the table
                    DefaultTableModel model = (DefaultTableModel) billTable.getModel();
                    boolean foodExists = false;
                    for(int i=0; i<model.getRowCount(); i++){
                        if(model.getValueAt(i, 0).equals(name)){
                            model.setValueAt(quantity, i, 2);
                            foodExists = true;
                            break;
                        }
                    }
                    if(!foodExists){
                        model.addRow(new Object[]{name, price, quantity, ingredients, calories, isVegetarian, customAdd, portionSize});
                    }
                    for(int i = model.getRowCount() -1; i>=0; i--){
                        if((int)model.getValueAt(i, 2)== 0){
                        model.removeRow(i);
                        }
                    }
                    updateTotals(); 
                } else {
                    // Show a message box if quantity is zero
                    JOptionPane.showMessageDialog(null, "Please select a valid quantity.", "Invalid Quantity", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                // Show a message box if quantity is invalid
                JOptionPane.showMessageDialog(null, "Invalid quantity entered. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            DefaultTableModel model = (DefaultTableModel) billTable.getModel();
            String name = "Burger";
            for(int i=0; i<model.getRowCount(); i++){
                if(model.getValueAt(i, 0).equals(name)){
                    model.removeRow(i);
                    break;
                }
            }
            updateTotals();
        }
    }//GEN-LAST:event_food4checkboxActionPerformed
    /**
     * Action listener for the jCheckBox6.
     * Validates the selected item and adds food details to the bill table.
     *
     * @param evt the event generated when the checkbox is clicked
     */
    private void food6CheckboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_food6CheckboxActionPerformed
        if (food6Checkbox.isSelected()) { // Check if another checkbox is selected
            foodie(); 
            try {
                // Get the quantity from the spinner
                int quantity = Integer.parseInt(food6Spinner.getValue().toString());

                // Check if quantity is valid
                if (quantity > 0) {
                    // Example food details
                    String name = "Sandwich";
                    double price = 350.0;
                    String ingredients = "Chicken, Tomato, Onion, Sauses";
                    int calories = 250;
                    boolean isVegetarian = false;
                    String customAdd = "No Add";
                    String portionSize = "One";

                    // Add details to the table
                    DefaultTableModel model = (DefaultTableModel) billTable.getModel();
                    boolean foodExists = false;
                    for(int i=0; i<model.getRowCount(); i++){
                        if(model.getValueAt(i, 0).equals(name)){
                            model.setValueAt(quantity, i, 2);
                            foodExists = true;
                            break;
                        }
                    }
                    if(!foodExists){
                        model.addRow(new Object[]{name, price, quantity, ingredients, calories, isVegetarian, customAdd, portionSize});
                    }
                    for(int i = model.getRowCount() -1; i>=0; i--){
                        if((int)model.getValueAt(i, 2)== 0){
                        model.removeRow(i);
                        }
                    }
                    updateTotals(); 
                } else {
                    // Show a message box if quantity is zero
                    JOptionPane.showMessageDialog(null, "Please select a valid quantity.", "Invalid Quantity", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                // Show a message box if quantity is invalid
                JOptionPane.showMessageDialog(null, "Invalid quantity entered. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            DefaultTableModel model = (DefaultTableModel) billTable.getModel();
            String name = "Burger";
            for(int i=0; i<model.getRowCount(); i++){
                if(model.getValueAt(i, 0).equals(name)){
                    model.removeRow(i);
                    break;
                }
            }
            updateTotals();
        }
    }//GEN-LAST:event_food6CheckboxActionPerformed

    private void food7CheckboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_food7CheckboxActionPerformed
        if (food7Checkbox.isSelected()) { // Check if another checkbox is selected
            foodie(); 
            try {
                // Get the quantity from the spinner
                int quantity = Integer.parseInt(food7Spinner.getValue().toString());

                // Check if quantity is valid
                if (quantity > 0) {
                    // Example food details
                    String name = "Fried rice";
                    double price = 400.0;
                    String ingredients = "Chicken, Vegetables, Sause";
                    int calories = 600;
                    boolean isVegetarian = false;
                    String customAdd = "Less oil";
                    String portionSize = "medium";
                    
                    // Add details to the table
                    DefaultTableModel model = (DefaultTableModel) billTable.getModel();
                    boolean foodExists = false;
                    for(int i=0; i<model.getRowCount(); i++){
                        if(model.getValueAt(i, 0).equals(name)){
                            model.setValueAt(quantity, i, 2);
                            foodExists = true;
                            break;
                        }
                    }
                    if(!foodExists){
                        model.addRow(new Object[]{name, price, quantity, ingredients, calories, isVegetarian, customAdd, portionSize});
                    }
                    for(int i = model.getRowCount() -1; i>=0; i--){
                        if((int)model.getValueAt(i, 2)== 0){
                        model.removeRow(i);
                        }
                    }
                    updateTotals(); 
                } else {
                    // Show a message box if quantity is zero
                    JOptionPane.showMessageDialog(null, "Please select a valid quantity.", "Invalid Quantity", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                // Show a message box if quantity is invalid
                JOptionPane.showMessageDialog(null, "Invalid quantity entered. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            DefaultTableModel model = (DefaultTableModel) billTable.getModel();
            String name = "Burger";
            for(int i=0; i<model.getRowCount(); i++){
                if(model.getValueAt(i, 0).equals(name)){
                    model.removeRow(i);
                    break;
                }
            }
            updateTotals();
        }      
    }//GEN-LAST:event_food7CheckboxActionPerformed

    private void food8CheckboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_food8CheckboxActionPerformed
        if (food8Checkbox.isSelected()) { // Check if another checkbox is selected
            foodie(); 
            try {
                // Get the quantity from the spinner
                int quantity = Integer.parseInt(food8Spinner.getValue().toString());

                // Check if quantity is valid
                if (quantity > 0) {
                    // Example food details
                    String name = "Fried Chicken";
                    double price = 1200.0;
                    String ingredients = "Chicken, Bread Crumps, Spices";
                    int calories = 800;
                    boolean isVegetarian = false;
                    String customAdd = "Extra Spicy";
                    String portionSize = "Large";
                    
                    // Add details to the table
                    DefaultTableModel model = (DefaultTableModel) billTable.getModel();
                    boolean foodExists = false;
                    for(int i=0; i<model.getRowCount(); i++){
                        if(model.getValueAt(i, 0).equals(name)){
                            model.setValueAt(quantity, i, 2);
                            foodExists = true;
                            break;
                        }
                    }
                    if(!foodExists){
                        model.addRow(new Object[]{name, price, quantity, ingredients, calories, isVegetarian, customAdd, portionSize});
                    }
                    for(int i = model.getRowCount() -1; i>=0; i--){
                        if((int)model.getValueAt(i, 2)== 0){
                        model.removeRow(i);
                        }
                    }
                    updateTotals(); 
                } else {
                    // Show a message box if quantity is zero
                    JOptionPane.showMessageDialog(null, "Please select a valid quantity.", "Invalid Quantity", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                // Show a message box if quantity is invalid
                JOptionPane.showMessageDialog(null, "Invalid quantity entered. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            DefaultTableModel model = (DefaultTableModel) billTable.getModel();
            String name = "Burger";
            for(int i=0; i<model.getRowCount(); i++){
                if(model.getValueAt(i, 0).equals(name)){
                    model.removeRow(i);
                    break;
                }
            }
            updateTotals(); 
        }
    }//GEN-LAST:event_food8CheckboxActionPerformed
    /**
     * Action listener for the login button.
     * Validates user credentials and loads the main screen upon successful login.
     *
     * @param evt the event generated when the button is clicked
     */
    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed
        
//        if (userField.getText().equals("")) {
//            JOptionPane.showMessageDialog(null, "Please fill out username");
//        }// TODO add your handling code here:
//        else if (passwordField.getText().equals("")) {
//            JOptionPane.showMessageDialog(null, "Please fill out password");
//        } else if (userField.getText().contains("admin") && passwordField.getText().contains("admin")) {
//            JOptionPane.showMessageDialog(null, "LOgin successfully!!");
//            loadScreen("MainScreen");
        if(!validationUtil.isInputValid(userField.getText(), "Username")){
            return;
        }else if(!validationUtil.isInputValid(passwordField.getText(), "Password")){
            return;
        }else if(userField.getText().equals("admin")&&passwordField.getText().equals("admin")){
            JOptionPane.showMessageDialog(null, "Login successfully!!");
            loadScreen("MainScreen");
        }else {
            JOptionPane.showMessageDialog(null, "Wrong username or password!!!!!", "Message", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_loginButtonActionPerformed
    /**
     * Action performed when the "Cancel" button is clicked.
     * Disposes of the current frame.
     *
     * @param evt the event triggered by the button click
     */
    private void cancleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancleButtonActionPerformed
        this.dispose();// TODO add your handling code here:
    }//GEN-LAST:event_cancleButtonActionPerformed
    /**
     * Action performed when the "Bill" button is clicked.
     * Currently commented out for future implementation.
     *
     * @param evt the event triggered by the button click
     */
    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        DefaultTableModel model = (DefaultTableModel) billTable.getModel();
        int selectedRow = billTable.getSelectedRow();
        if(!validationUtil.isRowSelected(selectedRow)){
            return;
        }
        if (selectedRow != -1){
            model.removeRow(selectedRow);
            JOptionPane.showMessageDialog(this, "Food item deleted successfully!", "Delete", JOptionPane.INFORMATION_MESSAGE);
            updateTotals();
        }else {
        JOptionPane.showMessageDialog(this, "Please select a food item to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_deleteButtonActionPerformed
     /**
     * Action performed for sorting food items by price using Selection Sort.
     *
     * @param evt the event triggered by the button click
     */
    private void sorting1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sorting1ActionPerformed
        List<food> sortedList = selectionSort.sortByPrice(billList, false);// Sort the list by price
        loadListToTable(sortedList);// Load sorted data into the table
        JOptionPane.showMessageDialog(this, "Sorting by Price completed successefully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_sorting1ActionPerformed
      /**
     * Action performed for sorting food items by name using Insertion Sort.
     *
     * @param evt the event triggered by the button click
     */
    private void sorting2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sorting2ActionPerformed
        List<food> sortedList = InsertSort.sortByName(billList, false); // Sort the list by name
        loadListToTable(sortedList);// Load sorted data into the table
        JOptionPane.showMessageDialog(this, "Sorting by Name completed successefully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_sorting2ActionPerformed
        /**
     * Action performed for sorting food items by calorie using Merge Sort.
     *
     * @param evt the event triggered by the button click
     */
    private void sorting3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sorting3ActionPerformed
        List<food> sortedList = MergeSort.sortByCalorie(billList, false);// Sort the list by calorie
        loadListToTable(sortedList);// Load sorted data into the table
        JOptionPane.showMessageDialog(this, "Sorting by Calorie completed successefully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_sorting3ActionPerformed
     /**
     * Searches for a food item by its name using Binary Search.
     *
     * @param evt the event triggered by the button click
     */
    private void SearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchButtonActionPerformed
        String SearchKey = SearchTextField.getText().trim();// Get the search key from the text field
        if (SearchKey.isEmpty()){
            // Show a warning if the search key is empty
            javax.swing.JOptionPane.showMessageDialog(this, "Please enter a food name to search.", "Input Error", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        if(billList == null || billList.isEmpty()){
            // Show an error if the list is empty
            javax.swing.JOptionPane.showMessageDialog(this, "The food list is empty.", "Data Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }
// Sort the list by name before performing the search
        List<food> sortedList = InsertSort.sortByName(billList, false);
        
        food searchData = BinarySearch.searchByName(SearchKey, sortedList,0, sortedList.size() -1);
        if (searchData != null){
            // If item is found, display it
            List<food> updateList = new ArrayList<>();
            updateList.add(searchData);
            loadListToTable(updateList);
        }else{
            // If item is not found, display a warning
            javax.swing.JOptionPane.showMessageDialog(this, "Sorry, food name not found.", "Search Result", javax.swing.JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_SearchButtonActionPerformed

    private void billButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_billButton1ActionPerformed
        DefaultTableModel model = (DefaultTableModel) billTable.getModel();
        StringBuilder billDetails = new StringBuilder();
        double totalPrice = 0.0;
        int totalItems = 0;
        // Build the bill details string
        billDetails.append("Bill Details:\n");
        billDetails.append("******************************************************************************\n");
        billDetails.append(String.format("%-20s %-10s %-10s %-10s\n", "Name", "Price", "Quantity", "Total"));
        billDetails.append("******************************************************************************\n");
        
        for (int i = 0; i < model.getRowCount(); i++) {
            String name = (String) model.getValueAt(i, 0);
            double price = (Double) model.getValueAt(i, 1);
            int quantity = (Integer) model.getValueAt(i, 2);
            double itemTotal = price * quantity;
            
            // Validate quantity
            if (!validationUtil.isQuantityValid(quantity)) {
                return; // Exit if validation fails
            }
            billDetails.append(String.format("%-20s %-10.2f %-10d %-10.2f\n", name, price, quantity, itemTotal));
            totalPrice += itemTotal;
            totalItems += quantity;
        }
        billDetails.append("*************************************************\n");
        billDetails.append(String.format("Total Items: %d\n", totalItems));
        billDetails.append(String.format("Total Price: %.2f\n", totalPrice));
        billDetails.append("*************************************************\n");

    // Show the bill details in a dialog
    JOptionPane.showMessageDialog(this, billDetails.toString(), "Bill Summary", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_billButton1ActionPerformed

    private void UpdateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateButtonActionPerformed
       DefaultTableModel model = (DefaultTableModel) billTable.getModel();
       int selectedRow = billTable.getSelectedRow();
       
       if (selectedRow != -1){
            String Ingredients = (String) model.getValueAt(selectedRow, 3);
            boolean IsVegetrain = (Boolean) model.getValueAt(selectedRow, 5);
            
            IsVegetrain = !IsVegetrain;
            Ingredients = Ingredients.replace("Chicken", "").replaceAll(",\\s*,", ",").trim(); // Remove chicken and clean up

        // Update the model with new values
            model.setValueAt(IsVegetrain, selectedRow, 5); // Update isVegetrain
            model.setValueAt(Ingredients, selectedRow, 3);
            JOptionPane.showMessageDialog(this, "Food item updated successfully!", "Update", JOptionPane.INFORMATION_MESSAGE);
        } else {
        JOptionPane.showMessageDialog(this, "Please select a food item to update.", "No Selection", JOptionPane.WARNING_MESSAGE);
       }
    }//GEN-LAST:event_UpdateButtonActionPerformed
    /**
     * Generates a formatted string for the bill header.
     */
    public void foodie() {
        billDate.setText("""
                         ***********************************************************************************************************************************************************
                         Time: """ + dateTime1.getText() + "             Date: " + dateTime.getText() + "\n"
                + "*****************************************************************************************************************************************************************"+"\n"
                + "");

    }
    /**
     * Continuously updates the time and date displayed in the application.
     * Runs in a separate thread to ensure real-time updates.
     */
    private void setTime() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        Logger.getLogger(foodOrder.class.getName()).log(Level.SEVERE, null, e);
                    }
                    Date date = new Date();
                    SimpleDateFormat tf = new SimpleDateFormat("h:mm:ss aa");
                    SimpleDateFormat df = new SimpleDateFormat("EEEE, dd-MM-yyyy");

                    String time = tf.format(date);
                    String dateString = df.format(date);
                    // Update GUI components on the Event Dispatch Thread
                    SwingUtilities.invokeLater(() -> {
                        dateTime1.setText(time); // Assuming time format is correct here
                        dateTime.setText(dateString);
                    });
                }
            }
        }).start();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        

        /* Create and display the form */
        foodOrder food = new foodOrder();
        java.awt.EventQueue.invokeLater(() -> {
            food.setVisible(true);

        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel FinalBill;
    private javax.swing.JLabel NavImage;
    private javax.swing.JLabel PasswordText;
    private javax.swing.JButton SearchButton;
    private javax.swing.JTextField SearchTextField;
    private javax.swing.JButton UpdateButton;
    private javax.swing.JButton billButton1;
    private javax.swing.JTextArea billDate;
    private javax.swing.JPanel billDetails;
    private javax.swing.JTable billTable;
    private javax.swing.JScrollPane billTextfield;
    private javax.swing.JButton cancleButton;
    private javax.swing.JPanel dashboard;
    private javax.swing.JLabel dateTime;
    private javax.swing.JLabel dateTime1;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JPanel food1;
    private javax.swing.JLabel food1Burger;
    private javax.swing.JCheckBox food1Checkbox;
    private javax.swing.JLabel food1Image;
    private javax.swing.JLabel food1Name;
    private javax.swing.JLabel food1P;
    private javax.swing.JLabel food1Price;
    private javax.swing.JLabel food1Purchase;
    private javax.swing.JLabel food1Quantity;
    private javax.swing.JSpinner food1Spinner;
    private javax.swing.JPanel food2;
    private javax.swing.JLabel food2Image;
    private javax.swing.JLabel food2Name;
    private javax.swing.JLabel food2P;
    private javax.swing.JLabel food2Pizza;
    private javax.swing.JLabel food2Price;
    private javax.swing.JLabel food2Purchase;
    private javax.swing.JLabel food2Quantity;
    private javax.swing.JSpinner food2Spinner;
    private javax.swing.JCheckBox food2checkbox;
    private javax.swing.JPanel food3;
    private javax.swing.JCheckBox food3Checkbox;
    private javax.swing.JLabel food3Image;
    private javax.swing.JLabel food3MoMo;
    private javax.swing.JLabel food3Name;
    private javax.swing.JLabel food3P;
    private javax.swing.JLabel food3Price;
    private javax.swing.JLabel food3Purchase;
    private javax.swing.JLabel food3Quantity;
    private javax.swing.JSpinner food3Spinner;
    private javax.swing.JPanel food4;
    private javax.swing.JLabel food4Image;
    private javax.swing.JLabel food4Name;
    private javax.swing.JLabel food4P;
    private javax.swing.JLabel food4Pasta;
    private javax.swing.JLabel food4Price;
    private javax.swing.JLabel food4Purchase;
    private javax.swing.JLabel food4Qunatity;
    private javax.swing.JSpinner food4Spinner;
    private javax.swing.JCheckBox food4checkbox;
    private javax.swing.JPanel food5;
    private javax.swing.JCheckBox food5Checkbox;
    private javax.swing.JLabel food5Image;
    private javax.swing.JLabel food5Name;
    private javax.swing.JLabel food5P;
    private javax.swing.JLabel food5Price;
    private javax.swing.JLabel food5Purchase;
    private javax.swing.JLabel food5Quantity;
    private javax.swing.JLabel food5Spaghetti;
    private javax.swing.JSpinner food5Spinner;
    private javax.swing.JPanel food6;
    private javax.swing.JCheckBox food6Checkbox;
    private javax.swing.JLabel food6Image;
    private javax.swing.JLabel food6Name;
    private javax.swing.JLabel food6P;
    private javax.swing.JLabel food6Price;
    private javax.swing.JLabel food6Purchase;
    private javax.swing.JLabel food6Quantity;
    private javax.swing.JLabel food6Sandwich;
    private javax.swing.JSpinner food6Spinner;
    private javax.swing.JPanel food7;
    private javax.swing.JCheckBox food7Checkbox;
    private javax.swing.JLabel food7Friedrice;
    private javax.swing.JLabel food7Image;
    private javax.swing.JLabel food7Name;
    private javax.swing.JLabel food7P;
    private javax.swing.JLabel food7Price;
    private javax.swing.JLabel food7Purchase;
    private javax.swing.JLabel food7Quantity;
    private javax.swing.JSpinner food7Spinner;
    private javax.swing.JPanel food8;
    private javax.swing.JCheckBox food8Checkbox;
    private javax.swing.JLabel food8Chicken;
    private javax.swing.JLabel food8Image;
    private javax.swing.JLabel food8Name;
    private javax.swing.JLabel food8P;
    private javax.swing.JLabel food8Price;
    private javax.swing.JLabel food8Purchase;
    private javax.swing.JLabel food8Quantity;
    private javax.swing.JSpinner food8Spinner;
    private javax.swing.JPanel footerPanel;
    private javax.swing.JTextField itemTextField;
    private javax.swing.JLabel items;
    private javax.swing.JProgressBar loading;
    private javax.swing.JPanel loadingPage;
    private javax.swing.JLabel loadingPageImage1;
    private javax.swing.JPanel login;
    private javax.swing.JButton loginButton;
    private javax.swing.JPanel loginDetails;
    private javax.swing.JLabel loginImage;
    private javax.swing.JLabel loginText;
    private javax.swing.JPanel logopanel;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel menuField;
    private javax.swing.JLabel menuText;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JButton resetButton;
    private javax.swing.JButton sorting1;
    private javax.swing.JButton sorting2;
    private javax.swing.JButton sorting3;
    private javax.swing.JLabel subTotal;
    private javax.swing.JTextField subTotalTextField;
    private javax.swing.JLabel tax;
    private javax.swing.JTextField taxTextField;
    private javax.swing.JScrollPane timeTextfield;
    private javax.swing.JLabel totalPrice1;
    private javax.swing.JTextField totalTextField;
    private javax.swing.JTextField userField;
    private javax.swing.JLabel userText;
    private javax.swing.JLabel welcomeText1;
    private javax.swing.JLabel welcomeText2;
    private javax.swing.JLabel welcomeText3;
    private javax.swing.JLabel welcomeText4;
    private javax.swing.JLabel welcomeText5;
    // End of variables declaration//GEN-END:variables

    private void loadScreen(String loadingScreen) {
        cardLayout.show(getContentPane(), loadingScreen);
    }

}
